package edu.afit.scpsolver;

import edu.afit.scpsolver.ast.Family;

public interface PrintCommand {
	String print(Family arg0);
}